package ru.raiffeisen.interfaces;

import java.util.Properties;

/**
 * Created by ostkyg on 30.06.2017.
 */
public interface RunCheckSQLInterface {

    Integer GetResult(Properties properties);

}
