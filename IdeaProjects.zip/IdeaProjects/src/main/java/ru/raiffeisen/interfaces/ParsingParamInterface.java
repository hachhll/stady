package ru.raiffeisen.interfaces;

        import java.util.Properties;

/**
 * Created by ostkyg on 30.06.2017.
 */
public interface ParsingParamInterface {

    Properties GetPropConnection(String propFileName, String sqlString);

    Properties GetPropConnection(String conn_string, String user_name, String password, String sqlString);
}
