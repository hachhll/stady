package ru.raiffeisen.core;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.raiffeisen.interfaces.ParsingParamInterface;
import ru.raiffeisen.interfaces.RunCheckSQLInterface;

/**
 * Created by ostkyg on 30.06.2017.
 */
public class CheckSourceStatusJDBC {
    private static final Logger logger = LogManager.getLogger(CheckSourceStatusJDBC.class.getName());

    public static void main(String... args) {
        logger.info("Start CheckSourceStatusJDBC application ");

        if (args.length < 2) {
            logger.error("\n Please add arguments with switch two different cases: \n " +
                    "1: Two arguments with property file for Sqoop with values for connection to DB and SQL string  \n  " +
                    "2: Four arguments with values of connect string, user name, password and SQL string");
            throw new IllegalArgumentException("Arguments an insufficient amount. It need 2 or 4 arguments");
        }

        Integer resultSqlCheck = 0;
        RunCheckSQLInterface checker = new RunCheckSQL();
        ParsingParamInterface prop = new ParsingParams();
        Properties properties = new Properties();
        switch (args.length) {
            case 2: {
                logger.info("Run check existing values by JDBC with param file");
                properties = prop.GetPropConnection(args[0], args[1]);
                break;
            }
            case 4: {
                logger.info("Run check existing values by JDBC with credentials");
                properties = prop.GetPropConnection(args[0], args[1], args[3], args[4]);
                break;
            }
            default: {
                throw new IllegalArgumentException("Arguments an incorrect amount. It need 2 or 4 arguments");
            }
        }

        resultSqlCheck = checker.GetResult(properties);

        logger.info(resultSqlCheck);

    }

}
