package ru.raiffeisen.core;

import java.sql.*;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import ru.raiffeisen.interfaces.RunCheckSQLInterface;

/**
 * Created by ostkyg on 30.06.2017.
 */
public class RunCheckSQL implements RunCheckSQLInterface {

    private static final Logger logger = LogManager.getLogger(RunCheckSQL.class.getName());

    public Integer GetResult(Properties properties) {

        String connect_str = properties.getProperty("connect");
        String connect_username = properties.getProperty("username");
        String connect_password = properties.getProperty("password");
        String connect_sql = properties.getProperty("sqlstring");

        int cnt_res = 0;
        Integer conunt_res = null;

        try {
            //Connect to DB
            Connection conn = DriverManager.getConnection(connect_str, connect_username, connect_password);
            try {
                logger.info("Creating statement...");
                Statement stmt = conn.createStatement();
                try {
                    logger.info("Execute SQL:" + connect_sql);
                    ResultSet rs = stmt.executeQuery(connect_sql);
                    try {
                        while (rs.next()) {
                            conunt_res = rs.getInt(1);
                            logger.info("Sql result val = " + conunt_res);
                            cnt_res += 1;
                        }

                    } finally {
                        if (!rs.isClosed() || rs != null) ;
                    }
                } catch (SQLException e) {
                    logger.error("ResultSet SQLException from SQL: " + connect_sql);
                    throw new SQLException(e.getMessage());
                } finally {
                    if (!stmt.isClosed()) stmt.close();
                }
            } finally {
                if (!conn.isClosed()) conn.close();
            }
        } catch (SQLException se) {
            se.printStackTrace();
        }
        try {
            if (cnt_res > 1) {
                conunt_res = 0;
                throw new SQLException("Many result. Result must be 0 or 1");
            }
            if (conunt_res > 0) conunt_res = 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return conunt_res;
    }
}
