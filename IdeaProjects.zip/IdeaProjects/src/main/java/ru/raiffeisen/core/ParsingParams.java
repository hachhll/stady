package ru.raiffeisen.core;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

import ru.raiffeisen.interfaces.ParsingParamInterface;

/**
 * Created by ostkyg on 30.06.2017.
 */
public class ParsingParams implements ParsingParamInterface {

    public Properties GetPropConnection(String propFileName, String sqlStrin) {

        String[] ReadFile(String propFileName);

        return null;
    }

    public Properties GetPropConnection(String conn_string, String user_name, String password, String sqlString) {
        return null;
    }

    private String[] ReadFile(String filename) throws Exception {
        StringBuilder sb = null;
        //Load file
        BufferedReader br = new BufferedReader(new FileReader(filename));
        //Read file
        try {
            sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(" ");
                line = br.readLine();
            }

        } finally {
            br.close();
        }
        //Split finally string
        return sb.toString().split(" ");
    }
}
