package ru.raiffeisen.datalake;

import java.math.BigDecimal;
import java.sql.*;

import java.util.Properties;

/**
 * Created by ruayra2 on 11.04.2017.
 */
public class CheckSourceStatusJDBC {
    private Properties props;

    public Integer ConnectAndExecute() {
        //init
        String connect_str = this.props.getProperty("connect");
        String connect_username = this.props.getProperty("username");
        String connect_password = this.props.getProperty("password");
        String connect_sql = this.props.getProperty("sqlstring");

        int cnt_res = 0;
        Integer conunt_res = null;

        try {
            //Connect to DB
            Connection conn = DriverManager.getConnection(connect_str, connect_username, connect_password);
            try {
                //STEP 2: Register JDBC driver
                //Class.forName(driver_conn);

                //STEP 3: Open a connection
//            System.out.println("Connecting to :" + connect_str);
//            System.out.println("username:" + connect_username);
//            System.out.println("password:" + connect_password);
//            System.out.println("sqlstring:" + connect_sql);


                //STEP 4: Execute a query
                System.out.println("Creating statement...");
                Statement stmt = conn.createStatement();
                try {
                    //
                    System.out.println("Execute SQL:" + connect_sql);
                    ResultSet rs = stmt.executeQuery(connect_sql);

                    //STEP 5: Extract data from result set

                    try {

                        while (rs.next()) {
                            conunt_res = rs.getInt(1);
                            System.out.println("Sql result val = "+conunt_res);
                            cnt_res += 1;
                        }

                    } finally {
                        if (!rs.isClosed() || rs != null) ;
                    }
                }catch (SQLException e) {
                    System.out.println("ResultSet SQLException from SQL: "+ connect_sql);
                    System.out.println(e.getMessage());
                }finally {
                    if (!stmt.isClosed()) stmt.close();
                }
            } finally {
                if (!conn.isClosed()) conn.close();
            }
        } catch (SQLException se) {
            se.printStackTrace();
        }
        try {
            if (cnt_res > 1) {
                conunt_res=0;
                throw new SQLException("Many result. Result must be 0 or 1");
            }
            if (conunt_res > 0) conunt_res = 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return conunt_res;
    }

    public void addManyProperty(Properties addprops) {
        props.putAll(addprops);
    }

    public void setProperty(String name, String value) {
        props.setProperty(name, value);
    }

    public String getProperty(String name) {
        return props.getProperty(name);
    }

    /**
     *
     */
    public CheckSourceStatusJDBC() {
        this.props = new Properties();
    }

    public CheckSourceStatusJDBC(String propfile, String sqlstring) {

        this();

        this.setProperty("propfilename", propfile);
        this.setProperty("sqlstring", sqlstring);

        try {
            ParseSqoopPropFile sf = new ParseSqoopPropFile(propfile);
            this.addManyProperty(sf.getProperties());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public CheckSourceStatusJDBC(String connect, String username, String password, String sqlstring) {

        this();

        this.setProperty("connect", connect);
        this.setProperty("username", username);
        this.setProperty("password", password);
        this.setProperty("sqlstring", sqlstring);

    }

}
