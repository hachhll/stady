package ru.raiffeisen.datalake;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 *
 */
public class CheckSourceStatus {

    public static void main(String[] args) throws Exception {

//        CheckSourceStatusJMS jj = new CheckSourceStatusJMS();
//
//        jj.start();

        System.out.println("Start CheckSourceStatus version by 2017-06-29");

        CheckSourceStatusJDBC checker = null;

        //check input params
        if (args.length!=4&args.length!=2){
            throw new Exception("Error args number. Current:"+args.length+" must: 4 or 2");
        }

        if (args.length==2){
            System.out.println("Use prop files");
            checker = new CheckSourceStatusJDBC(args[0],args[1]);
        }
        if (args.length==4){
            System.out.println("Use direct setting");
            checker = new CheckSourceStatusJDBC(args[0],args[1],args[2],args[3]);
        }

        Integer res = checker.ConnectAndExecute();

        System.out.println("Result:"+res);

        try{
            String oozie_file = System.getProperty("oozie.action.output.properties");

            if (oozie_file == null)
                throw new Exception("Property: 'oozie.action.output.properties' not found");

            File file = new File(oozie_file);
            Properties props = new Properties();
            props.setProperty("checkresult", res.toString());

            OutputStream os = new FileOutputStream(file);
            props.store(os, "Ok");
            os.close();

            System.out.println(file.getAbsolutePath());
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Done.");
        }
    }
}
