package ru.raiffeisen.datalake;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

/**
 * Created by ruayra2 on 11.04.2017.
 */
public class ParseSqoopPropFile {
    private Properties v_props;
    private String v_file_name;


    /**
     * @param filename
     * @return String[] splitted params
     * @throws Exception
     */

    private String[] ReadFile(String filename) throws Exception {
        StringBuilder sb = null;
        //Load file
        BufferedReader br = new BufferedReader(new FileReader(filename));
        //Read file
        try {
            sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(" ");
                line = br.readLine();
            }

        } finally {
            br.close();
        }
        //Split finally string
        return sb.toString().split(" ");
    }

    private void ParseParams(String[] params) {
        String param_name = "";
        String param_value = "";
        Properties pp = new Properties();

        for (int c = 0; c < params.length; c = c + 1) {
            String param = params[c];

            if (param.length() > 0) {

                if (param.startsWith("--")) {
                    param_name = param.replace("--", "").toLowerCase().trim();
                    param_value = "";
                    //System.out.println("Name:"+param);
                } else {
                    if (!param_name.isEmpty())
                        param_value = param.replace("\"", "");
                    //System.out.println("Value:"+param);
                }

                if (!param_name.isEmpty() && !param_value.isEmpty()) {
                    pp.setProperty(param_name, param_value);
                    param_name = "";
                    param_value = "";
                }

            }

        }

        v_props = pp;
    }


    public ParseSqoopPropFile(String propFileName) throws Exception {
        //init
        v_file_name = propFileName;
        //Load and split files
        String[] params = ReadFile(v_file_name);
        //Parse aprams
        ParseParams(params);

    }

    public String getConnect() {
        return v_props.getProperty("connect");
    }

    public String getUserName() {
        return v_props.getProperty("username");
    }

    public String getPassword() {
        return v_props.getProperty("password");
    }

    public Properties getProperties() {
        return v_props;
    }

}
