package ru.raiffeisen.datalake;

import org.apache.log4j.Logger;

import javax.jms.JMSException;
import javax.jms.Session;
import java.util.Properties;

/**
 * Created by ruayra2 on 04.05.2017.
 */


public class CheckSourceStatusJMS {

    //Property for topic
    private Properties props;

    //Check properties
    private void checkProperties(){
        props.getProperty("QueueManager");
        props.getProperty("ClientID");
        props.getProperty("HostName");
        props.getProperty("Port");
        props.getProperty("Channel");
        props.getProperty("User");
        props.getProperty("Password");
    }


    //logger
    private static final Logger log = Logger.getLogger("Application");

    void start() throws JMSException {

        //Check settings
        //checkProperties();

        com.ibm.mq.jms.MQTopicConnectionFactory f = new com.ibm.mq.jms.MQTopicConnectionFactory();
        /*
        Хост ruaas02f
        Порт 1416
        Менеджер QMMSKCC1
        Канал QAS.MSKCC1
        Топик CORESTATE
        */
        log.info("Start");

        f.setTransportType(1);
        f.setQueueManager("QMMSKCC1");
        f.setClientID("XXXXX");
        f.setHostName("RUAAS02F");
        f.setPort(1416);
        f.setChannel("QAS.MSKCC1");

        javax.jms.Connection c = f.createConnection("C1USER01", "c1user01");
        c.start();
        javax.jms.Session session = c.createSession(false, Session.AUTO_ACKNOWLEDGE);

        com.ibm.mq.jms.MQTopic topic = new com.ibm.mq.jms.MQTopic();
        topic.setBaseTopicName("CORESTATE");

        javax.jms.TopicSubscriber topicSubscriber = session.createDurableSubscriber( topic, "testStagg" );

        log.info("start receive");
        javax.jms.Message m = topicSubscriber.receive((long)60000); //miliseconds
        log.info("end recieve");
        if ( m != null )
            System.out.print(m.toString());

        //add commect

        topicSubscriber.close();
        session.unsubscribe("testStagg");
        session.close();
        c.stop();
        c.close();

    }

}
